package ir.adliehban.app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;
import android.provider.CalendarContract.Instances;
import android.provider.CalendarContract.Reminders;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.TimeZone;

/**
 * JavaScript-visible wrapper around the Android Calendar Provider.
 * All methods return JSON strings (or primitives) so the web layer stays simple.
 */
public class CalendarBridge {

    private final MainActivity activity;

    CalendarBridge(MainActivity activity) {
        this.activity = activity;
    }

    private ContentResolver cr() {
        return activity.getContentResolver();
    }

    private boolean granted() {
        return activity.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
                && activity.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    private static String error(String message) {
        try {
            return new JSONObject().put("ok", false).put("error", message).toString();
        } catch (Exception e) {
            return "{\"ok\":false}";
        }
    }

    @JavascriptInterface
    public boolean hasPermission() {
        return granted();
    }

    @JavascriptInterface
    public void requestPermission() {
        activity.requestCalendarPermission();
    }

    /** Writable calendars: [{id,name,account,primary}] */
    @JavascriptInterface
    public String listCalendars() {
        JSONArray out = new JSONArray();
        if (!granted()) return out.toString();
        Cursor c = null;
        try {
            c = cr().query(Calendars.CONTENT_URI,
                    new String[]{Calendars._ID, Calendars.CALENDAR_DISPLAY_NAME,
                            Calendars.ACCOUNT_NAME, Calendars.OWNER_ACCOUNT},
                    Calendars.CALENDAR_ACCESS_LEVEL + " >= ?",
                    new String[]{String.valueOf(Calendars.CAL_ACCESS_CONTRIBUTOR)},
                    Calendars.ACCOUNT_NAME + " ASC");
            while (c != null && c.moveToNext()) {
                String account = c.getString(2);
                String owner = c.getString(3);
                out.put(new JSONObject()
                        .put("id", c.getLong(0))
                        .put("name", c.getString(1))
                        .put("account", account == null ? "" : account)
                        .put("primary", account != null && account.equals(owner)));
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return out.toString();
    }

    private long defaultCalendarId() {
        try {
            JSONArray all = new JSONArray(listCalendars());
            for (int i = 0; i < all.length(); i++) {
                if (all.getJSONObject(i).optBoolean("primary")) return all.getJSONObject(i).getLong("id");
            }
            if (all.length() > 0) return all.getJSONObject(0).getLong("id");
        } catch (Exception ignored) {
        }
        return -1;
    }

    private boolean eventExists(long id) {
        Cursor c = null;
        try {
            c = cr().query(ContentUris.withAppendedId(Events.CONTENT_URI, id),
                    new String[]{Events._ID}, Events.DELETED + "=0", null, null);
            return c != null && c.moveToFirst();
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.close();
        }
    }

    /**
     * Creates or updates an event.
     * json: {title, description, location, start, end, reminders:[minutes], calendarId, existingId}
     * returns {"ok":true,"eventId":N,"updated":bool}
     */
    @JavascriptInterface
    public String upsertEvent(String json) {
        if (!granted()) return error("NO_PERMISSION");
        try {
            JSONObject o = new JSONObject(json);
            long calendarId = o.optLong("calendarId", 0);
            if (calendarId <= 0) calendarId = defaultCalendarId();
            if (calendarId <= 0) return error("NO_CALENDAR");

            ContentValues v = new ContentValues();
            v.put(Events.TITLE, o.optString("title"));
            v.put(Events.DESCRIPTION, o.optString("description"));
            v.put(Events.EVENT_LOCATION, o.optString("location"));
            v.put(Events.DTSTART, o.getLong("start"));
            v.put(Events.DTEND, o.getLong("end"));
            v.put(Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
            v.put(Events.HAS_ALARM, 1);

            long existing = o.optLong("existingId", 0);
            long eventId;
            boolean updated = false;
            if (existing > 0 && eventExists(existing)) {
                cr().update(ContentUris.withAppendedId(Events.CONTENT_URI, existing), v, null, null);
                cr().delete(Reminders.CONTENT_URI, Reminders.EVENT_ID + "=?",
                        new String[]{String.valueOf(existing)});
                eventId = existing;
                updated = true;
            } else {
                v.put(Events.CALENDAR_ID, calendarId);
                Uri uri = cr().insert(Events.CONTENT_URI, v);
                if (uri == null) return error("INSERT_FAILED");
                eventId = ContentUris.parseId(uri);
            }

            JSONArray reminders = o.optJSONArray("reminders");
            if (reminders != null) {
                for (int i = 0; i < reminders.length(); i++) {
                    ContentValues r = new ContentValues();
                    r.put(Reminders.EVENT_ID, eventId);
                    r.put(Reminders.MINUTES, reminders.getInt(i));
                    r.put(Reminders.METHOD, Reminders.METHOD_ALERT);
                    cr().insert(Reminders.CONTENT_URI, r);
                }
            }
            return new JSONObject().put("ok", true).put("eventId", eventId).put("updated", updated).toString();
        } catch (Exception e) {
            return error(String.valueOf(e.getMessage()));
        }
    }

    @JavascriptInterface
    public String deleteEvent(String eventId) {
        if (!granted()) return error("NO_PERMISSION");
        try {
            int rows = cr().delete(ContentUris.withAppendedId(Events.CONTENT_URI, Long.parseLong(eventId)), null, null);
            return new JSONObject().put("ok", true).put("rows", rows).toString();
        } catch (Exception e) {
            return error(String.valueOf(e.getMessage()));
        }
    }

    /** Events overlapping [startMs, endMs): [{id,title,begin,end,allDay,calendar,location}] */
    @JavascriptInterface
    public String listEvents(String startMs, String endMs) {
        JSONArray out = new JSONArray();
        if (!granted()) return out.toString();
        Cursor c = null;
        try {
            Uri.Builder b = Instances.CONTENT_URI.buildUpon();
            ContentUris.appendId(b, Long.parseLong(startMs));
            ContentUris.appendId(b, Long.parseLong(endMs));
            c = cr().query(b.build(),
                    new String[]{Instances.EVENT_ID, Instances.TITLE, Instances.BEGIN, Instances.END,
                            Instances.ALL_DAY, Instances.CALENDAR_DISPLAY_NAME, Instances.EVENT_LOCATION},
                    null, null, Instances.BEGIN + " ASC");
            int n = 0;
            while (c != null && c.moveToNext() && n < 300) {
                out.put(new JSONObject()
                        .put("id", c.getLong(0))
                        .put("title", c.getString(1) == null ? "" : c.getString(1))
                        .put("begin", c.getLong(2))
                        .put("end", c.getLong(3))
                        .put("allDay", c.getInt(4) == 1)
                        .put("calendar", c.getString(5) == null ? "" : c.getString(5))
                        .put("location", c.getString(6) == null ? "" : c.getString(6)));
                n++;
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return out.toString();
    }
}
